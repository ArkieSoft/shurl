# Shurl-cli
A terminal-based TinyUrl wrapper that uses curl to pull a shortened link.



### Use ###

Simple. type "shurl <PASTE URL HERE>" and hit enter. 


### Installation ###

First, clone the repo.

Second, build with cargo

"cargo build --release"

Third, install to /usr/local/bin

"install -Dm 755 ./shurl-cli /usr/local/bin"

On Mac, drop the D

"install -m 755 ./shurl-cli /usr/local/bin"

This is my first project so don't expect miracles out of little old me
